from flask import Flask, render_template, request, redirect, url_for
import joblib

app = Flask(__name__)

# Load the model
model = joblib.load('happy.joblib')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/predict')
def predict():
    return render_template('courses.html')

@app.route('/submit', methods=['POST'])
def submit():
    # Retrieve form data
    infoavail = float(request.form['infoavail'])
    housecost = float(request.form['housecost'])
    schoolquality = float(request.form['schoolquality'])
    policetrust = float(request.form['policetrust'])
    streetquality = float(request.form['streetquality'])
    events = float(request.form['events'])
    
    # Create a feature array for prediction
    features = [[infoavail, housecost, schoolquality, policetrust, streetquality, events]]
    
    # Predict happiness level
    prediction = model.predict(features)
    predict_value = prediction[0]
    
    return render_template('events.html', predict=predict_value)

if __name__ == '__main__':
    app.run(debug=True)
